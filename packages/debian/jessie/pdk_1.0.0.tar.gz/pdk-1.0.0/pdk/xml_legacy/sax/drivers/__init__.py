"Directory for SAX version 1 drivers."
