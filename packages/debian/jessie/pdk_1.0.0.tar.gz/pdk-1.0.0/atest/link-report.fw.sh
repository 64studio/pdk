
. atest/utils/repogen-fixture.sh

set_up_repogen_fixture link-report
pushd link-report


cat >links.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <deb>
      <cond><![CDATA[ apache2-common (<=2.0.54) ]]></cond>
      <meta>
        <link>
          <vuln>CAN-30</vuln>
        </link>
      </meta>
    </deb>
  </contents>
  <entities>
    <vuln id="CAN-30">
      <description>bad bad bad</description>
    </vuln>
  </entities>
</component>
EOF

cat >product.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <component>links.xml</component>
    <component>progeny.com/apache.xml</component>
  </contents>
</component>
EOF

pdk dumplinks product.xml >report.txt

diff -u - report.txt <<EOF
deb|md5:5acd04d4cc6e9d1530aad04accdc8eb5|vuln|CAN-30
EOF




cat >unlink.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <deb>
      <cond><![CDATA[ apache2-common (>= 2.0.53-5) ]]></cond>
      <meta>
        <unlink>
          <vuln>CAN-30</vuln>
        </unlink>
      </meta>
    </deb>
  </contents>
</component>
EOF

cat >product.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <component>links.xml</component>
    <component>unlink.xml</component>
    <component>progeny.com/apache.xml</component>
  </contents>
</component>
EOF

pdk dumplinks product.xml >report.txt

diff -u - report.txt <<EOF
EOF




cat >links.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <deb>
      <cond><![CDATA[ apache2-common (<< 2.0.53-5) ]]></cond>
      <meta>
        <link>
          <vuln>CAN-31</vuln>
        </link>
      </meta>
    </deb>
    <deb>
      <cond><![CDATA[ apache2-common (>>2.0.52 <=2.0.53-5) ]]></cond>
      <meta>
        <link>
          <vuln>CAN-30</vuln>
        </link>
      </meta>
    </deb>
  </contents>
  <entities>
    <vuln id="CAN-30">
      <description>bad bad bad</description>
    </vuln>
    <vuln id="CAN-31">
      <description>not so bad</description>
    </vuln>
  </entities>
</component>
EOF

cat >product.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <component>links.xml</component>
    <component>progeny.com/apache.xml</component>
  </contents>
</component>
EOF


pdk dumplinks product.xml >report.txt

diff -u - report.txt <<EOF
deb|md5:5acd04d4cc6e9d1530aad04accdc8eb5|vuln|CAN-30
EOF




cat >links.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <deb>
      <cond><![CDATA[ apache2-common (=2.0.53-5) | apache3 ]]></cond>
      <meta>
        <link>
          <vuln>CAN-31</vuln>
        </link>
      </meta>
    </deb>
    <deb>
      <cond><![CDATA[ apache2-common (>>2.0.52 <=2.0.53-5) ]]></cond>
      <meta>
        <link>
          <vuln>CAN-30</vuln>
        </link>
      </meta>
    </deb>
  </contents>
  <entities>
    <vuln id="CAN-30">
      <description>bad bad bad</description>
    </vuln>
    <vuln id="CAN-31">
      <description>not so bad</description>
    </vuln>
  </entities>
</component>
EOF

pdk dumplinks product.xml | LANG=C sort >report.txt

diff -u - report.txt <<EOF
deb|md5:5acd04d4cc6e9d1530aad04accdc8eb5|vuln|CAN-30
deb|md5:5acd04d4cc6e9d1530aad04accdc8eb5|vuln|CAN-31
EOF



cat >links.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <dsc>
      <cond><![CDATA[ * apache2 ]]></cond>
      <meta>
        <link>
          <vuln>CAN-30</vuln>
        </link>
      </meta>
    </dsc>
  </contents>
  <entities>
    <vuln id="CAN-30">
      <description>bad bad bad</description>
    </vuln>
  </entities>
</component>
EOF

pdk dumplinks product.xml | LANG=C sort >report.txt

diff -u - report.txt <<EOF
deb|md5:5acd04d4cc6e9d1530aad04accdc8eb5|vuln|CAN-30
EOF



cat >links.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <bin>
      <cond><![CDATA[ * apache2-common ]]></cond>
      <meta>
        <link>
          <vuln>CAN-31</vuln>
        </link>
      </meta>
    </bin>
    <src>
      <cond><![CDATA[ * apache2 ]]></cond>
      <meta>
        <link>
          <vuln>CAN-30</vuln>
        </link>
      </meta>
    </src>
  </contents>
  <entities>
    <vuln id="CAN-30">
      <description>bad bad bad</description>
    </vuln>
  </entities>
</component>
EOF

pdk dumplinks product.xml | LANG=C sort >report.txt

diff -u - report.txt <<EOF
deb|md5:5acd04d4cc6e9d1530aad04accdc8eb5|vuln|CAN-30
dsc|md5:d94c995bde2f13e04cdd0c21417a7ca5|vuln|CAN-31
EOF




popd

