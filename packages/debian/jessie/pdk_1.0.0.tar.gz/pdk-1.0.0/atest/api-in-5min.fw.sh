
. atest/utils/repogen-fixture.sh

set_up_repogen_fixture link-report
pushd link-report


cat >names.py <<EOF
# boilerplate
import sys
from pdk.workspace import current_workspace

raw_component_filename = sys.argv[1]
ws = current_workspace()
component_filename = ws.reorient_filename(raw_component_filename)
descriptor = ws.get_component_descriptor(component_filename)
cache = ws.world.get_backed_cache(ws.cache)
component = descriptor.load(cache)

# meat
for package in component.iter_packages():
    print package.name, package.version.full_version, package.role

EOF

python names.py progeny.com/apache.xml >output.txt

diff -u - output.txt <<EOF
apache2-common 2.0.53-5 binary
apache2 2.0.53-5 source
EOF



cat >entity-links.py <<EOF
# boilerplate
import sys
from pdk.workspace import current_workspace

raw_component_filename = sys.argv[1]
ws = current_workspace()
component_filename = ws.reorient_filename(raw_component_filename)
descriptor = ws.get_component_descriptor(component_filename)
cache = ws.world.get_backed_cache(ws.cache)
component = descriptor.load(cache)

# meat
for package in component.iter_packages():
    print package.name, package.version.full_version, package.role
    for link_key in package.links:
        entity = component.entities[link_key]
        print '    ', entity.ent_type, entity.ent_id, \
            entity['pdk', 'description']

EOF

cat >some-entities.py <<EOF
<component>
  <contents>
    <dsc>
      <name>apache2</name>
      <meta>
        <link>
          <bug>0098</bug>
        </link>
      </meta>
    </dsc>
    <component>progeny.com/apache.xml</component>
  </contents>
  <entities>
    <bug id="0098">
      <description>Woo, bad bad bad.</description>
    </bug>
  </entities>
</component>
EOF

python entity-links.py some-entities.py >output.txt

diff -u - output.txt <<EOF
apache2-common 2.0.53-5 binary
apache2 2.0.53-5 source
     bug 0098 Woo, bad bad bad.
EOF


cat >make-simple-repo.py <<EOF
# boilerplate
import sys
from pdk.workspace import current_workspace

raw_component_filename = sys.argv[1]
ws = current_workspace()
component_filename = ws.reorient_filename(raw_component_filename)
descriptor = ws.get_component_descriptor(component_filename)
ws.download([descriptor])
cache = ws.cache
component = descriptor.load(cache)

# meat
import os
directory = sys.argv[2]
os.makedirs(directory)
for package in component.iter_packages():
    all_files = [ package.filename ] + \
        [ f[2] for f in package.extra_files ]
    for filename in all_files:
        filepath = os.path.join(directory, filename)
        print filepath
        os.link(cache.file_path(package.ent_id), filepath)

EOF

python make-simple-repo.py progeny.com/apache.xml repo

find repo | LANG=C sort >output.txt

diff -u - output.txt <<EOF
repo
repo/apache2-common_2.0.53-5_i386.deb
repo/apache2_2.0.53-5.diff.gz
repo/apache2_2.0.53-5.dsc
repo/apache2_2.0.53.orig.tar.gz
EOF


cat >changeit.py <<EOF
# boilerplate
import sys
from pdk.workspace import current_workspace

raw_component_filename = sys.argv[1]
ws = current_workspace()
component_filename = ws.reorient_filename(raw_component_filename)
descriptor = ws.get_component_descriptor(component_filename)

# meat
del descriptor.contents[0].children[1]
descriptor.write()
EOF

# ---------------------------------
# Before
# ---------------------------------

cp progeny.com/apache.xml changeme.xml

diff -u - changeme.xml <<EOF
<?xml version="1.0" encoding="utf-8"?>
<component>
  <contents>
    <dsc>
      <name>apache2</name>
      <deb ref="md5:5acd04d4cc6e9d1530aad04accdc8eb5">
        <name>apache2-common</name>
        <version>2.0.53-5</version>
        <arch>i386</arch>
      </deb>
      <dsc ref="md5:d94c995bde2f13e04cdd0c21417a7ca5">
        <name>apache2</name>
        <version>2.0.53-5</version>
      </dsc>
    </dsc>
  </contents>
</component>
EOF

# ---------------------------------
# Run the script...
# ---------------------------------

python changeit.py changeme.xml

# ---------------------------------
# After
# ---------------------------------

diff -u - changeme.xml <<EOF
<?xml version="1.0" encoding="utf-8"?>
<component>
  <contents>
    <dsc>
      <name>apache2</name>
      <deb ref="md5:5acd04d4cc6e9d1530aad04accdc8eb5">
        <name>apache2-common</name>
        <version>2.0.53-5</version>
        <arch>i386</arch>
      </deb>
    </dsc>
  </contents>
</component>
EOF



popd

