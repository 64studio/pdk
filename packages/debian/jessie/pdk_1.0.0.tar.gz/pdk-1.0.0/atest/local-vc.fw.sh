

. atest/test_lib.sh
. atest/utils/test_channel.sh



assert_status() {
    set +x
    local message="$1"
    local expected=$tmp_dir/expected_status
    local actual=$tmp_dir/actual_status
    shift

    echo $* '' >$expected
    cat >>$expected

    echo -n >$actual
    for suffix in a b c d; do
        file=file-$suffix
        echo -n $(wc -l <$file) '' >>$actual
    done
    echo >>$actual
    pdk status >>$actual

    diff -u $expected $actual \
        || fail "status mismatch: $message"
    set -x
}





pdk workspace create mv-command
mkdir mv-command/subdir
pushd mv-command/subdir
    echo 1 > file-a
    pdk commit -m 'initial' file-a
    pdk mv file-a file-b
    pdk status >../../status.txt
    diff -u - ../../status.txt <<EOF
R100	subdir/file-a	subdir/file-b
EOF
    pdk commit -m 'after mv'
    mkdir somedir
    echo 2 > somedir/file-c
    pdk commit -m 'add with dir' somedir/file-c
    pdk mv somedir anotherdir 2>../../errors.txt \
        && fail 'Command should have failed'
    grep -q 'directory' ../../errors.txt
    pdk mv somedir/file-c file-b 2>../../errors.txt \
        && fail 'Command should have failed'
    grep -q 'exist' ../../errors.txt
popd


pdk workspace create commit-reg-subdir-1
pushd commit-reg-subdir-1
    mkdir subdir
    echo info >>subdir/file-a
    pdk commit -m 'test regression' subdir/file-a
    pushd subdir
    echo info >>file-a
    pdk commit -m 'test regression' file-a
    popd
popd

pdk workspace create commit-reg-subdir-2
pushd commit-reg-subdir-2
    mkdir subdir
    pushd subdir
    echo info >>file-a
    pdk commit -m 'test regression' file-a
    echo info >>file-a
    pdk commit -m 'test regression' file-a
    popd
popd



pdk workspace create commit-ordering
pushd commit-ordering
    echo 1 >file
    pdk commit -m '>> a' file
    echo 2 >file
    pdk commit -m '>> b' file
    echo 3 >file
    pdk commit -m '>> c' file
    pdk log | grep '^>>' > ../log.txt
    diff -u - ../log.txt <<EOF
>> c
>> b
>> a
EOF
popd



pdk workspace create no-commits-allowed
pushd no-commits-allowed

    # log command
    pdk log 2>../errors.txt || status=$?
    [ "$status" = 3 ] || fail 'pdk log should have failed.'
    grep -i log ../errors.txt

    # empty status
    pdk status >../status.txt
    diff -u - ../status.txt <<EOF
EOF

    # status after adding files.
    echo "Hello World!" >hello.txt
    pdk add hello.txt
    echo "Now is the time for" >>all.txt
    pdk status >../status.txt
    diff -u - ../status.txt <<EOF
A	hello.txt
?	all.txt
EOF

popd



pdk workspace create add-and-commit
pushd add-and-commit

    echo info >>file-a
    echo info >>file-b
    echo info >>file-c
    echo info >>file-d
    pdk add file-a
    echo "Initial Commit" | pdk commit -f -
    assert_status "after add + raw" 1 1 1 1 <<EOF
?	file-b
?	file-c
?	file-d
EOF

    echo info >>file-a
    echo "Add comment." | pdk commit -f -
    assert_status "after change + raw" 2 1 1 1 <<EOF
?	file-b
?	file-c
?	file-d
EOF

    echo info >>file-b
    echo "Add file file-b" | pdk commit -f - file-b
    assert_status "after commit + file, not added" 2 2 1 1 <<EOF
?	file-c
?	file-d
EOF

    echo info >>file-c
    pdk add file-c
    echo "Add file file-c" | pdk commit -f - file-c
    assert_status "after commit + file, already added" 2 2 2 1 <<EOF
?	file-d
EOF

    echo info >>file-a
    echo info >>file-d
    pdk add file-d
    echo "Modify file-a" | pdk commit -f - file-a
    assert_status "after commit + file, another file added then changed" \
        3 2 2 2 <<EOF
A	file-d
EOF

    echo info >>file-d
    echo "Add file-d" | pdk commit -f -
    assert_status "after commit raw, added file changed" 3 2 2 3 <<EOF
EOF


    cat >$tmp_dir/bin/fake_editor <<EOF
cat >\$1 <<MSG
message produced by fake editor
MSG
EOF
    chmod +x $tmp_dir/bin/fake_editor
    EDITOR=fake_editor
    export EDITOR
    echo info >>file-a
    pdk commit
    unset EDITOR
    assert_status "after commit with EDITOR" 4 2 2 3 <<EOF
EOF
    git cat-file commit HEAD | grep fake

    echo info >>file-a
    pdk commit -m 'Message from command line.'
    assert_status "after commit with EDITOR" 5 2 2 3 <<EOF
EOF
    git cat-file commit HEAD | grep "command line"

popd




pdk workspace create add-and-commit-multi-arg
pushd add-and-commit-multi-arg
    echo 1 >>file-a
    echo 1 >>file-b
    echo 1 >>file-c
    echo 1 >>file-d
    pdk add  file-a file-b
    pdk commit -m "multi arg add"
    assert_status "after add + raw" 1 1 1 1 <<EOF
?	file-c
?	file-d
EOF

    pdk commit -m "multi arg commit" file-b file-c file-d
    assert_status "after add + raw" 1 1 1 1 <<EOF
EOF
popd



pdk workspace create commit-reg-initial-cmd-line
pushd commit-reg-initial-cmd-line
    echo info >>file-a
    pdk commit -m 'Initial commit' file-a
popd



pdk workspace create cat
pushd cat
    pdk cat file-a file-b 2>errors.txt || status=$?
    [ "$status" = 2 ] || fail "cat with too many arguments should fail"
    grep -i 'single filename' errors.txt

    echo 1 >>file-a
    pdk cat file-a 2>errors.txt || status=$?
    [ "$status" = 4 ] || fail "cat before file-a commit should fail"
    grep -i 'commit' errors.txt

    pdk commit -m 'initial' file-a

    pdk cat file-a >file-a.cat
    diff -u - file-a.cat <<EOF
1
EOF

    echo 2 >>file-a
    pdk cat file-a >file-a.cat
    diff -u - file-a.cat <<EOF
1
EOF
    pdk commit -m 'add 2'
    pdk cat file-a >file-a.cat
    diff -u - file-a.cat <<EOF
1
2
EOF

    # watch for regression where cat only looks at the git index.
    echo 3 >>file-a
    GIT_INDEX_FILE=etc/git/pdk/pdk-index git update-index file-a
    pdk cat file-a >file-a.cat
    diff -u - file-a.cat <<EOF
1
2
EOF
    pdk commit -m 'add 3'
    pdk cat file-a >file-a.cat
    diff -u - file-a.cat <<EOF
1
2
3
EOF

    pdk cat file-b 2>errors.txt || status=$?
    [ "$status" = 4 ] || fail "cat unknown file should fail"
    grep -i 'no file' errors.txt

    # watch for regression where cat doesn't work in subdirectories.
    mkdir subdir
    echo 1 >>subdir/file-b
    pdk commit -m 'add file-b in subdir' subdir/file-b
    echo 2 >>subdir/file-b
    pdk cat subdir/file-b >file-b.cat
    diff -u - file-b.cat <<EOF
1
EOF

popd



pdk workspace create remove
pushd remove
    echo info >>file-a
    pdk commit -m 'Initial Commit' file-a

    pdk remove file-a || status=$?
    [ -f 'file-a' ] \
        || fail 'file-a should still exist after pdk remove.'
    [ "$status" = 4 ] || fail 'pdk remove should fail when file exists'

    rm file-a
    pdk remove file-a
    pdk status >../output.txt
    diff -u - ../output.txt <<EOF
D	file-a
EOF
    pdk commit -m 'remove file-a'

    pdk status >../output.txt
    diff -u - ../output.txt <<EOF
EOF

    echo info >>file-a
    pdk commit -m 'add it back' file-a
    rm file-a
    pdk rm file-a
    pdk status >../output.txt
    diff -u - ../output.txt <<EOF
D	file-a
EOF
    pdk commit -m 'remove it with commit arg.' file-a
    pdk status >../output.txt
    diff -u - ../output.txt <<EOF
EOF


    echo info >>file-a
    echo info >>file-b

    pdk commit -m 'add two files: file-a file-b' file-a file-b
    rm file-a
    pdk commit -m 'rm file-a with args only' file-a \
        && fail 'should not be able to rm with args only'
    pdk status >../output.txt
    diff -u - ../output.txt <<EOF
!	file-a
EOF

    rm file-b
    pdk remove file-a file-b
    pdk commit -m 'rm both files at once.'

    pdk status >../output.txt
    diff -u - ../output.txt <<EOF
EOF

    # Wild corner case: Remove a file and delete the directory it is
    # in, then commit.

    mkdir somedir
    echo info >>somedir/delete-me
    pdk commit -m 'put one file in a directory' somedir/delete-me
    rm -r somedir
    pdk remove somedir/delete-me
    pdk commit -m 'remove the file and the directory at the same time'
    pdk status >../output.txt
    diff -u - ../output.txt <<EOF
EOF

    # Use of the '-f' force option:

    echo info >>force-remove
    pdk commit -m 'Before force remove' force-remove
    pdk remove -f force-remove
    [ -e force-remove ] && fail 'pdk remove -f should unlink file'
    pdk status >../output.txt
    diff -u - ../output.txt <<EOF
D	force-remove
EOF
    pdk commit -m 'After force remove'
    pdk status >../output.txt
    diff -u - ../output.txt <<EOF
EOF

popd



pdk workspace create revert
pushd revert
    echo >>file-a 1
    echo >>file-b 1
    echo >>file-c 1
    pdk commit -m 'Initial Commit' file-a file-b file-c

    echo >>file-a 2
    echo >>file-b 2
    echo >>file-c 2
    pdk revert file-a file-c

    diff -u - file-a <<EOF
1
EOF
    diff -u - file-b <<EOF
1
2
EOF
    diff -u - file-c <<EOF
1
EOF

    echo "hello" >file-d
    pdk add file-d
    pdk revert file-d

    pdk status >../status.txt
    diff -u - ../status.txt <<EOF
M	file-b
?	file-d
EOF
    pdk commit -m 'Commit'

    # corner case: revert immediately after remoove
    rm file-b
    pdk remove file-b
    pdk revert file-b

popd


pdk workspace create update
pushd update

    echo info >>file-a.txt

    pdk add file-a.txt
    pdk commit -m 'Jam Session 5 testing'

    rm file-a.txt
    pdk update
    diff -u - file-a.txt <<EOF
info
EOF

popd


pdk workspace create status
pushd status
    # don't recurse into unknown directories
    mkdir unknown
    echo info >unknown/a
    echo info >unknown/b
    echo info >unknown/c
    pdk status >../output.txt
    diff -u - ../output.txt <<EOF
?	unknown/
EOF
    rm -r unknown

    echo info >>file-a
    pdk commit -m "Initial Commit" file-a
    pdk status >../output.txt
    diff -u - ../output.txt <<EOF
EOF

    echo info >>file-a
    echo info >>file-b
    pdk status >../output.txt
    diff -u - ../output.txt <<EOF
M	file-a
?	file-b
EOF

    pdk commit -m "A Local Change"
    pdk status >../output.txt
    diff -u - ../output.txt <<EOF
?	file-b
EOF

    # try to catch a rename.
    pdk add file-b
    pdk commit -m 'Add file b.'

    mv file-b file-c
    pdk remove file-b
    pdk add file-c
    pdk status >../output.txt
    diff -u - ../output.txt <<EOF
R100	file-b	file-c
EOF
    pdk commit -m 'rename file-b to file-c'

    # Regression: File committed as empty, then modified: Status bombs.
    touch some-file
    pdk add some-file
    pdk commit -m 'initial empty'
    pdk status
    echo 'hello world!' >some-file
    pdk status

popd


check_dir_failure() {
    unset status
    "$@" 2>stderr.txt || local status=$?
    cat stderr.txt
    [ "$status" == 3 ] || fail "expected exit value 3, got $status"
    grep director stderr.txt
}

pdk workspace create dirs
pushd dirs
    mkdir somedir
    check_dir_failure pdk add somedir
    check_dir_failure pdk commit -m 'msg' somedir/

    touch somedir/a
    pdk commit -m 'initial' somedir/a
    check_dir_failure pdk remove somedir

    check_dir_failure pdk cat somedir
popd

