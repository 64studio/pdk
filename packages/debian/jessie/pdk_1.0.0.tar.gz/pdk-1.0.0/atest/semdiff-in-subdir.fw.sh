
pdk workspace create semdiff
pushd semdiff

mkdir channel-1
cp \
    ${PACKAGES}/emacs-defaults_1.1_all.deb \
    ${PACKAGES}/emacs-defaults_1.1.dsc \
    ${PACKAGES}/emacs-defaults_1.1.tar.gz \
    channel-1

cat >etc/channels.xml <<EOF
<?xml version="1.0"?>
<channels>
  <channel-1>
    <type>dir</type>
    <path>channel-1</path>
  </channel-1>
</channels>
EOF

pdk channel update



mkdir progeny.com
cat >progeny.com/emacs.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <dsc>emacs-defaults</dsc>
  </contents>
</component>
EOF

pdk commit -m 'old version' progeny.com/emacs.xml

pdk resolve -R progeny.com/emacs.xml
pdk semdiff progeny.com/emacs.xml


popd semdiff
