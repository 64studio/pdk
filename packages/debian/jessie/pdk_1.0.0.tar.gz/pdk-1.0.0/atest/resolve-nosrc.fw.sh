

pdk workspace create nosrc
pushd nosrc
    cat >etc/channels.xml <<EOF
<channels>
  <nosrc>
    <type>dir</type>
    <path>$(pwd)/nosrc-channel</path>
  </nosrc>
</channels>
EOF

    mkdir nosrc-channel
    cp $PACKAGES/nosrc-test*.rpm nosrc-channel

    pdk channel update
    cat >nosrc.xml <<EOF
<component>
  <contents>
    <srpm>nosrc-test</srpm>
  </contents>
</component>
EOF
    pdk resolve -R nosrc.xml

    diff -u - nosrc.xml <<EOF
<?xml version="1.0" encoding="utf-8"?>
<component>
  <contents>
    <srpm>
      <name>nosrc-test</name>
      <rpm ref="md5:efb3e78f4fe0df8381d32d0e91c9a218">
        <name>nosrc-test</name>
        <version>1-1</version>
        <arch>i386</arch>
      </rpm>
      <srpm ref="md5:6f2249dc906e63dffe77981c81e16b06">
        <name>nosrc-test</name>
        <version>1-1</version>
      </srpm>
    </srpm>
  </contents>
</component>
EOF

popd
