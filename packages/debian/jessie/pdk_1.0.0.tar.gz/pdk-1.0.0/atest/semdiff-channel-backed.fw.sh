
pdk workspace create semdiff
pushd semdiff

mkdir channel-1
cp \
    ${PACKAGES}/emacs-defaults_1.1_all.deb \
    ${PACKAGES}/emacs-defaults_1.1.dsc \
    ${PACKAGES}/emacs-defaults_1.1.tar.gz \
    channel-1

cat >etc/channels.xml <<EOF
<?xml version="1.0"?>
<channels>
  <channel-1>
    <type>dir</type>
    <path>channel-1</path>
  </channel-1>
</channels>
EOF

pdk channel update



cat >emacs.xml <<EOF
<?xml version="1.0"?>
<component>
  <contents>
    <dsc>emacs-defaults</dsc>
  </contents>
</component>
EOF

pdk resolve emacs.xml
pdk semdiff emacs.xml emacs.xml


popd semdiff
