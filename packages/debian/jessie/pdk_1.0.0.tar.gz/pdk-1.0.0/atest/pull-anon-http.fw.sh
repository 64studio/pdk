


. atest/utils/repogen-fixture.sh

set_up_repogen_fixture source

pdk workspace create dest


# set up http server
create_lighttpd_conf <<EOF
server.document-root = "$tmp_dir"
EOF
start_lighttpd




pushd dest


cat >etc/channels.xml <<EOF
<?xml version="1.0"?>
<channels>
  <product>
    <type>source</type>
    <path>http://localhost:$HTTP_PORT/source</path>
  </product>
  <product-ssl>
    <type>source</type>
    <path>https://localhost:$HTTPS_PORT/source</path>
  </product-ssl>
  <oops-404>
    <type>source</type>
    <path>http://localhost:$HTTP_PORT/product-zzz</path>
  </oops-404>
  <oops-direct-git>
    <type>source</type>
    <path>http://localhost:$HTTP_PORT/source/etc/git</path>
  </oops-direct-git>
</channels>
EOF


popd


pushd source
    pdk add progeny.com/*.xml
    pdk download progeny.com/*.xml
    pdk commit -m "git-production commit"
popd




pushd dest
    pdk pull oops-404 && fail '404 should cause failure'
    pdk pull oops-direct-git \
        && fail 'no remote workspace should cause failure'
    pdk pull product
    pdk download progeny.com/apache.xml
popd

diff -u source/etc/git/refs/heads/master \
    dest/etc/git/refs/heads/master

(cd source; ls progeny.com >$tmp_dir/expected)
(cd dest; ls progeny.com >$tmp_dir/actual)
diff -u $tmp_dir/expected $tmp_dir/actual \
    || fail 'checked out files should match'




pushd source
    echo >>progeny.com/apache.xml
    pdk commit -m 'a change'
popd




pushd dest
    pdk pull oops-404 && fail '404 should cause failure'
    pdk pull oops-direct-git \
        && fail 'no remote workspace should cause failure'
    pdk pull product
    pdk download progeny.com/apache.xml
popd

diff -u source/etc/git/refs/heads/master \
    dest/etc/git/refs/heads/master

(cd source; ls progeny.com >$tmp_dir/expected)
(cd dest; ls progeny.com >$tmp_dir/actual)
diff -u $tmp_dir/expected $tmp_dir/actual \
    || fail 'checked out files should match'




pushd dest
    pdk pull product-ssl
popd




pushd dest
    echo >>progeny.com/apache.xml
    pdk pull product 2>errors.txt\
        && fail "pdk pull should fail when workspace is dirty"
    grep -i uncommitted errors.txt
popd


